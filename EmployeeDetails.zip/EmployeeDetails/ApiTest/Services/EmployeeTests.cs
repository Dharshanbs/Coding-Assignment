﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeDetails.Services;
using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework.Internal;
using Microsoft.AspNetCore.Mvc;
using EmployeeDetails.Models;

namespace EmployeeApi.Tests
{
    [TestClass()]
    public class EmployeeTests
    {
        [TestMethod()]
        public void GetEmployeeByIdTest()
        {
            EmployeeService emp = new EmployeeService();

            var Employee = emp.GetEmployeeById(2);
            Assert.IsInstanceOfType(Employee, typeof(NotFoundResult));
        }

        [TestMethod()]
        public void AddEmployee()
        {
            EmployeeService emp = new EmployeeService();
            Employees emps = new Employees()
            {
                EmployeeName = "Rahul",
                Designation = "Faciliy Manager",
                Salary=1908080,
                Address="Bangalore"
            };

            var Employee = emp.AddEmployee(emps);
            Assert.IsNotNull(Employee);
        }

        [TestMethod()]
        public void UpdateEmployee()
        {
            EmployeeService emp = new EmployeeService();
            Employees emps = new Employees()
            {
                EmployeeName = "Rahul Sahay",
                Address = "Hubli"
            };

            var Employee = emp.AddEmployee(emps);
            Assert.IsNotNull(Employee);
        }

        [TestMethod()]
        public void DeleteEmployee()
        {
            EmployeeService emp = new EmployeeService();
            

            var Employee = emp.DeleteEmployees(2);
            Assert.IsInstanceOfType(Employee, typeof(NotFoundResult));
        }
    }
}