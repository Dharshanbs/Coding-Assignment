﻿using System;
using System.Collections.Generic;

namespace EmployeeDetails.Models
{
    public partial class Employees
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public int Salary { get; set; }
        public string Address { get; set; }
    }
}
