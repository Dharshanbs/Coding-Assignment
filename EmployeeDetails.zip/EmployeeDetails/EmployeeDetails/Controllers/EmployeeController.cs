﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDetails.IServices;
using EmployeeDetails.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        // GET: api/<EmployeeController>
        private readonly IEmployeeService employeeService;

        public EmployeeController(IEmployeeService employee)
        {
            employeeService = employee;
        }
        [HttpGet]
        [Route("[action]")]
        [Route("api/Employee/GetEmployee")]
        public IEnumerable<Employees> GetEmployee()
        {
            return employeeService.GetEmployees();
        }

        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<EmployeeController>
        [HttpPost]
        [Route("[action]")]
        [Route("api/Employee/AddEmployee")]
        [Authorize]
        public Employees AddEmployee(Employees emplpoyee)
        {
            return employeeService.AddEmployee(emplpoyee);
        }

        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        [Route("[action]")]
        [Route("api/Employee/UpdateEmployee")]
        public Employees UpdateEmployee(Employees emplpoyee)
        {
            return employeeService.UpdateEmployee(emplpoyee);
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        [Route("[action]")]
        [Route("api/Employee/DeleteEmployee")]
        [Authorize]
        public Employees DeleteEmployee(int id)
        {
            return employeeService.DeleteEmployees(id);
        }
    }
}
