﻿using EmployeeDetails.IServices;
using EmployeeDetails.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Services
{
    public class EmployeeService: IEmployeeService
    {
        EmployeeDetailsContext dbContext;

        public EmployeeService()
        {
        }

        public EmployeeService(EmployeeDetailsContext _db)
        {
            dbContext = _db;
        }

        public Employees AddEmployee(Employees employee)
        {
            if(employee!=null)
            {
                dbContext.Employees.Add(employee);
                dbContext.SaveChanges();
                return employee;
            }
            return null;
        }

        public Employees DeleteEmployees(int  id)
        {
            var employee = dbContext.Employees.FirstOrDefault(x => x.EmployeeId == id);
            dbContext.Entry(employee).State = EntityState.Deleted;
            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();
            return employee;

        }

        public Employees GetEmployeeById(int id)
        {
            var employee = dbContext.Employees.FirstOrDefault(x => x.EmployeeId == id);

            return employee;

        }

        public IEnumerable<Employees> GetEmployees()
        {
            var employee = dbContext.Employees.ToList();
            return employee;
            
        }

        public Employees UpdateEmployee(Employees employee)
        {
            dbContext.Entry(employee).State = EntityState.Modified;
            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();
            return employee;
        }
    }
}
