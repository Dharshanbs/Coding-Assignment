﻿using EmployeeDetails.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.IServices
{
    public interface IEmployeeService
    {
        IEnumerable<Employees> GetEmployees();
        Employees GetEmployeeById(int id);
        Employees AddEmployee(Employees employee);
        Employees UpdateEmployee(Employees employee);

        Employees DeleteEmployees(int id);



    }
}
